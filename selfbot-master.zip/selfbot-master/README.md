Self-Bot V2
============

A Telegram Bot based on [DBTeam bot](https://github.com/Josepdal/DBTeam).

Installation
------------
```bash
# Tested on Ubuntu 14.04, for other OSs check out https://github.com/yagop/telegram-bot/wiki/Installation
sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev make unzip git redis-server g++ libjansson-dev libpython-dev expat libexpat1-dev
```

```bash
سلام 
آموزش ساخت سلف ربات توسط 
#alireza_pt
در کانال آموزشي ساخت ربات ضد اسپم تلگرام به آيدي
@create_antispam_bot


کد ها رو در زير ميزارم طبق فيلم آموزشي عمل کنيد

sudo apt-get update

sudo apt-get upgrade

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev libevent-dev make unzip git redis-server g++ libjansson-dev libpython-dev expat libexpat1-dev


git clone https://github.com/alireza1998/self_bot

cd self_bot


./launch.sh install

موفق باشيد
```

Security Team
-----------------

[HAJ PRO](http://telegram.me/alireza_PT)<br>


Security Team Channel
-----------------

[my Team](http://telegram.me/create_antispam_bot)
